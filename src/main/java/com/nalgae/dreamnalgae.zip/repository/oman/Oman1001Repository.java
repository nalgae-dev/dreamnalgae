package com.nalgae.dreamnalgae.repository.oman;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nalgae.dreamnalgae.entity.oman.User;

public interface Oman1001Repository extends JpaRepository<User, String> {

}
